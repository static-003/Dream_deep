import tensorflow as tf
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import os

def load_image(path):
    img = Image.open(path)
    img = img.resize((512, 512))
    img = np.array(img) / 255.0
    img = tf.convert_to_tensor(img)
    img = tf.image.convert_image_dtype(img, dtype=tf.float32)
    img = tf.expand_dims(img, axis=0)
    return img

def save_and_show(img, filename="output/dreamed.jpg"):
    img = Image.fromarray(img)
    os.makedirs("output", exist_ok=True)
    img.save(filename)
    plt.imshow(img)
    plt.axis("off")
    plt.show()

def deprocess(img):
    img = img[0]
    img -= tf.reduce_mean(img)
    img /= (tf.math.reduce_std(img) + 1e-8)
    img *= 0.1
    img += 0.5
    img = tf.clip_by_value(img, 0, 1)
    img *= 255
    img = tf.cast(img, tf.uint8)
    return img.numpy()

base_model = tf.keras.applications.InceptionV3(include_top=False, weights='imagenet')
layers = ['mixed3', 'mixed5']
outputs = [base_model.get_layer(name).output for name in layers]
dream_model = tf.keras.Model(inputs=base_model.input, outputs=outputs)

def calc_loss(img, model):
    img_batch = tf.expand_dims(img, axis=0)
    img_batch = tf.keras.applications.inception_v3.preprocess_input(img_batch * 255)
    activations = model(img_batch)
    if len(activations) == 1:
        activations = [activations]
    loss = tf.reduce_sum([tf.reduce_mean(act) for act in activations])
    return loss

@tf.function
def deep_dream_step(img, model, step_size):
    with tf.GradientTape() as tape:
        tape.watch(img)
        loss = calc_loss(img, model)
    gradients = tape.gradient(loss, img)
    gradients /= tf.math.reduce_std(gradients) + 1e-8
    img += gradients * step_size
    img = tf.clip_by_value(img, 0.0, 1.0)
    return img

def run_deep_dream(img, steps=100, step_size=0.01):
    for step in range(steps):
        img = deep_dream_step(img, dream_model, step_size)
    return img

if __name__ == "__main__":
    original_img = load_image("images/sample.jpg")
    dreamed_img = run_deep_dream(original_img)
    result = deprocess(dreamed_img)
    save_and_show(result)
